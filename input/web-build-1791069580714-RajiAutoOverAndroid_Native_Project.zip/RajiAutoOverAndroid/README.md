# Raji Auto Over Brain — Native Android

This is a native Android Studio project based on the supplied V8 rotating multi-market bot. It does **not** use a WebView/browser.

## Included
- Hard-coded Deriv App ID (not displayed in the UI)
- PAT input
- Demo/Real selector with Real confirmation
- Native OkHttp REST authentication and WebSocket transport
- Eight 1-second Volatility markets
- DIGITOVER proposal/buy flow
- Existing multi-layer Over filter and market rotation logic ported from V8
- Martingale settings, stake cap, target and global loss limit
- Session P/L, trade count, wins, losses, win rate and current stake
- Technical logs sent only to Android Logcat, not displayed in the app

## Build
Open this folder in Android Studio and let Gradle sync. Then select **Build > Build APK(s)**.

The project uses Android Gradle Plugin 8.5.2, compileSdk 35, minSdk 26, and OkHttp 4.12.0.

## Important
Test with Demo first. Real mode sends live orders and requires the confirmation checkbox.
