Raji V8 Over Android v2. Target: Android 13+, 64-bit ARM.
This is a native Android port of the V8 strategy pattern from the supplied V8 logs:
8 markets, DIGITOVER 4+, 10-tick/5-tick/4-tick Sharp scoring, rotation after settlement,
2-loss market safety lock, adjustable Martingale, M0 reset after wins, session TP,
foreground service, Demo/Real selection.
Use Demo first. Validate authorization, tick subscriptions, proposal/buy, settlement, rotation and Stop before Real use.
