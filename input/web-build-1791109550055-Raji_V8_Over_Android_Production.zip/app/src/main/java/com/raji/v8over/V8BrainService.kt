package com.raji.v8over
import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.pow

class V8BrainService:Service(){
 companion object{var ui:((String,String,String)->Unit)?=null}
 private val markets=listOf("1HZ10V","1HZ15V","1HZ25V","1HZ30V","1HZ50V","1HZ75V","1HZ90V","1HZ100V")
 private val mem=HashMap<String,ArrayDeque<Int>>()
 private val losses=HashMap<String,Int>()
 private val log=ArrayDeque<String>()
 private val client=OkHttpClient.Builder().readTimeout(0,TimeUnit.MILLISECONDS).build()
 private var ws:WebSocket?=null;private var connected=false;private var running=false;private var open=false
 private var pat="";private var appId="";private var real=false;private var current="";private var lastRoute=""
 private var base=1.2;private var mult=2.0;private var maxM=5;private var m=0;private var stake=1.2;private var tp=10.0;private var minScore=15.0;private var pnl=0.0
 override fun onCreate(){super.onCreate();getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("v8","V8 Brain",NotificationManager.IMPORTANCE_LOW));startForeground(9,NotificationCompat.Builder(this,"v8").setContentTitle("Raji V8 Over").setContentText("V8 engine").setSmallIcon(android.R.drawable.stat_notify_sync).build());markets.forEach{mem[it]=ArrayDeque()}}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{when(i?.action){
  "CONNECT"->{pat=i.getStringExtra("pat")?:"";appId=i.getStringExtra("appId")?:"";real=i.getBooleanExtra("real",false);connect()}
  "START"->{base=i.getDoubleExtra("base",1.2);mult=i.getDoubleExtra("mult",2.0);maxM=i.getIntExtra("maxM",5);tp=i.getDoubleExtra("tp",10.0);minScore=i.getDoubleExtra("minScore",15.0);stake=base;startBrain()}
  "STOP"->{running=false;add("STOPPED — no new purchases.");publish()}};return START_STICKY}
 private fun connect(){ws?.cancel();add("Opening ${if(real)"REAL" else "DEMO"} WebSocket…");publish();ws=client.newWebSocket(Request.Builder().url("wss://ws.derivws.com/websockets/v3?app_id=$appId").build(),object:WebSocketListener(){
  override fun onOpen(w:WebSocket,r:Response){connected=true;w.send(JSONObject().put("authorize",pat).toString());add("WebSocket connected; authorizing…");publish()}
  override fun onMessage(w:WebSocket,t:String){try{handle(JSONObject(t))}catch(e:Exception){add("Parse error: ${e.message}");publish()}}
  override fun onFailure(w:WebSocket,t:Throwable,r:Response?){connected=false;add("WebSocket failure: ${t.message}");publish()}
  override fun onClosed(w:WebSocket,c:Int,reason:String){connected=false;add("WebSocket closed ($c)");publish()}})}
 private fun handle(j:JSONObject){when(j.optString("msg_type")){
  "authorize"->{add("Authorized ${j.optJSONObject("authorize")?.optString("loginid")?:"account"}.");markets.forEach{ws?.send(JSONObject().put("ticks",it).put("subscribe",1).toString())};publish()}
  "tick"->{val t=j.optJSONObject("tick")?:return;val s=t.optString("symbol");val d=String.format(Locale.US,"%.2f",t.optDouble("quote")).last().digitToInt();val a=mem[s]?:return;a.addLast(d);while(a.size>10)a.removeFirst();if(running&&!open)scan()}
  "proposal"->{val p=j.optJSONObject("proposal")?:return;val id=p.optString("id");if(id.isNotBlank()&&!open){ws?.send(JSONObject().put("buy").put("buy",id).put("price",stake).toString())}}
  "buy"->{open=true;current=j.optJSONObject("buy")?.optString("contract_id")?:"";add("BOUGHT #$current on $lastRoute. Waiting for expiry…");ws?.send(JSONObject().put("proposal_open_contract").put("contract_id",current).put("subscribe",1).toString());publish()}
  "proposal_open_contract"->{val c=j.optJSONObject("proposal_open_contract")?:return;if(c.optBoolean("is_sold")||c.optBoolean("is_expired"))settle(c)}}}
 private fun startBrain(){if(!connected){add("START rejected — connect first.");publish();return};running=true;add("BRAIN ACTIVE | ${if(real)"REAL" else "DEMO"} | 8 markets | SHARP filter | rotate every settled trade | lock after 2 losses | Martingale ON x$mult / max M$maxM.");publish()}
 private fun score(s:String):Double{val a=mem[s]?:return 0.0;if(a.size<10)return 0.0;val high=a.count{it>=5};val short=a.takeLast(5).count{it>=5};val rise=a.takeLast(4).zipWithNext().count{it.second>it.first};return high*1.25+short*1.8+rise*1.2}
 private fun scan(){if(pnl>=tp){running=false;add("TARGET +%.2f reached. New purchases locked.".format(pnl));publish();return};val ranked=markets.map{it to score(it)}.sortedByDescending{it.second};val pick=ranked.firstOrNull{it.second>=minScore&&((it.first!=lastRoute)||ranked.size==1)}?:return;lastRoute=pick.first;val a=mem[lastRoute]?:return;val high=a.count{it>=5};val short=a.takeLast(5).count{it>=5};val rise=a.takeLast(4).zipWithNext().count{it.second>it.first};add("ROUTE → $lastRoute (score %.2f)".format(pick.second));add("SIGNAL $lastRoute: DIGITOVER 4+ | stake %.2f | M$m | score=%.2f | high=%d/10 | short=%d/5 | rise=%d/3".format(stake,pick.second,high,short,rise));ws?.send(JSONObject().put("proposal",1).put("amount",stake).put("basis","stake").put("contract_type","DIGITOVER").put("currency","USD").put("duration",1).put("duration_unit","t").put("symbol",lastRoute).put("barrier","4").toString())}
 private fun settle(c:JSONObject){val profit=c.optDouble("profit",0.0);pnl+=profit;open=false;if(profit>0){m=0;stake=base;losses[lastRoute]=0;add("WIN $lastRoute: %+.2f | stake reset".format(profit))}else{m=(m+1).coerceAtMost(maxM);stake=base*mult.pow(m);losses[lastRoute]=(losses[lastRoute]?:0)+1;add("LOSS $lastRoute: %.2f | Martingale M$m → $%.2f".format(profit,stake));if((losses[lastRoute]?:0)>=2)add("SAFETY LOCK $lastRoute — rotate to strongest eligible alternative.")};publish();if(pnl>=tp){running=false;add("TARGET +%.2f reached. New purchases locked.".format(pnl))}else if(running)scan()}
 private fun add(s:String){log.addLast(s);while(log.size>160)log.removeFirst()}
 private fun publish(){ui?.invoke(if(running)"BRAIN ACTIVE" else if(connected)"CONNECTED / READY" else "READY","Session P/L: %.2f\nStake: %.2f\nM%d\nMarket: %s".format(pnl,stake,m,if(lastRoute.isBlank())"—" else lastRoute),log.joinToString("\n"))}
 override fun onBind(i:Intent?):IBinder?=null
 override fun onDestroy(){ws?.close(1000,"service destroyed");super.onDestroy()}
}