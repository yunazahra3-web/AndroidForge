package com.raji.v8over
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  val mode=findViewById<Spinner>(R.id.accountMode)
  mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("DEMO","REAL"))
  findViewById<Button>(R.id.connect).setOnClickListener{
   startService(Intent(this,V8BrainService::class.java).setAction("CONNECT").apply{
    putExtra("pat",findViewById<EditText>(R.id.pat).text.toString())
    putExtra("appId",findViewById<EditText>(R.id.appId).text.toString())
    putExtra("real",mode.selectedItem.toString()=="REAL")})}
  findViewById<Button>(R.id.start).setOnClickListener{
   startService(Intent(this,V8BrainService::class.java).setAction("START").apply{
    putExtra("base",findViewById<EditText>(R.id.baseStake).text.toString().toDoubleOrNull()?:1.2)
    putExtra("mult",findViewById<EditText>(R.id.multiplier).text.toString().toDoubleOrNull()?:2.0)
    putExtra("maxM",findViewById<EditText>(R.id.maxStep).text.toString().toIntOrNull()?:5)
    putExtra("tp",findViewById<EditText>(R.id.sessionTp).text.toString().toDoubleOrNull()?:10.0)
    putExtra("minScore",findViewById<EditText>(R.id.minScore).text.toString().toDoubleOrNull()?:15.0)})}
  findViewById<Button>(R.id.stop).setOnClickListener{startService(Intent(this,V8BrainService::class.java).setAction("STOP"))}
  V8BrainService.ui={s,m,l->runOnUiThread{findViewById<TextView>(R.id.status).text=s;findViewById<TextView>(R.id.metrics).text=m;findViewById<TextView>(R.id.log).text=l}}
 }
}