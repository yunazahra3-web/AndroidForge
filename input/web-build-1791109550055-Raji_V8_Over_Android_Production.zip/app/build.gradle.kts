plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.raji.v8over"; compileSdk=36
 defaultConfig { applicationId="com.raji.v8over"; minSdk=26; targetSdk=36; versionCode=2; versionName="2.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.16.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
